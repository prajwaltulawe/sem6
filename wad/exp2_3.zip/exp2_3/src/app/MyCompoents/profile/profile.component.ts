import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Profile } from '../../Profile'

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent {
  profiles:Profile[];
  currentStudentID: "";

  constructor( ){  
     this.profiles = [] 
  }

  getValue(studentId:string, studentEmail:string, studentPass:string, studentClass:string){
    var data = {
      userName: studentId,
      userId: studentEmail,
      userPassword: studentPass,
      class: studentClass
    };
    this.profiles.push(data);
  }
}