export class Profile{
    userName: string
    userId: string
    userPassword: string
    class: string
}