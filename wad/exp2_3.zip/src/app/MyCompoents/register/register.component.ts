import { Component } from '@angular/core';
import { ProfileComponent } from './../profile/profile.component';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

}
